License: GPL v3
Developer: N1ED
Website: https://n1ed.com

"n1theme" skin is theme for CKEditor 4 included into N1ED editor.
